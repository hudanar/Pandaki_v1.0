  var secureCb;
  var secureCbLabel;
  var wsUri;
  var consoleLog;
  var displayLog;
  var connectBut;
  var disconnectBut;
  var sendMessage;
  var sendBut;
  var clearLogBut;
  var evtSplit;
var username;
var message;
  function echoHandlePageLoad()
  { 
if (window.MozWebSocket)
    {
        logToConsole('<span style="color: red;"><strong>Info:</strong> This browser supports WebSocket using the MozWebSocket constructor</span>');
        window.WebSocket = window.MozWebSocket;
    }
    else if (!window.WebSocket)
    {
        logToConsole('<span style="color: red;"><strong>Error:</strong> This browser does not have support for WebSocket</span>');
        return;
    }

    // prefer text messages
    var uri = "ws://singateknologicoid-via.cloud.revoluz.io:49290";
    if (uri.indexOf("?") == -1) {
        uri += "?encoding=text";
    } else {
        uri += "&encoding=text";
    }
    websocket = new WebSocket(uri);;
    websocket.onmessage = function(evt) { onMessage(evt) };
	websocket.onopen = function(evt) { onOpen(evt) };
	//websocket.send("username nanda"); 
  }
   function onOpen(evt)
  {
   websocket.send("username "+sender.value);
}
  function onMessage(evt)
  {	
//  logToConsole(evt.data);
	evtSplit=evt.data.split(" ");
	username=evtSplit[0];
	//message=evtSplit[3];
	var i;
	for(i=3; i<evtSplit.length;i++ ){
	message+=(evtSplit[i]+" ");}
	//message=evt.data;
	if(username==="DARURAT"){
	websocket.onmessage = function(evt) { fakeOnMessage(evt) };	
	usernamedarurat=evtSplit[1];
	alert(evt.data);
	stopAlert(usernamedarurat);
	}else{
	alert(username+' : '+message);
	};
  }
function stopAlert(evt){
	websocket.send(sender.value+" stop "+evt);
location.reload();
	}

  
  window.addEventListener("load", echoHandlePageLoad, false);
