<!DOCTYPE html>
<html>
<head>
	<?php $this->load->view('head'); ?>
</head>

<body>
	<?php
		echo $this->session->userdata('grupUser');
		if ($this->session->userdata('grupUser')!="admin"){
		redirect('welcome');
	}?>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <?php $this->load->view('header'); ?>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
            <?php $this->load->view('top_list'); ?>
            <!-- end navbar-top-links -->
        </nav>
        <!-- end navbar top -->

        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php $this->load->view('navbar'); ?>
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Detail Info dan Tips</h1>
                </div>
                <!--End Page Header -->
            </div>
			<div class="row">
				<form role="form" method="post" action="<?php echo base_url();?>index.php/infoTips/add">
					<div class="form-group">
						<label>Judul</label>
						<input class="form-control" name="judul" required>
					</div>
					<div class="form-group">
						<label>Tipe</label>
						<select class="form-control" name="tipe" required>
							<option value ="tips">Tips</option>
							<option value ="info">Info</option>
							</select>
					</div>
					
					<div class="form-group">
						<label>Foto</label>
						<!---<input class="form-control" name="foto">	-->				
							<input type="file" name = "foto">
					</div>
					
					<div class="form-group">
						<label>Konten</label>
						<textarea class="form-control" rows="3" name="konten" required></textarea>
					</div>
					<button type="submit" class="btn btn-primary">Submit</button>
				</form>
			</div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url();?>assets/plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/pace/pace.js"></script>
    <script src="<?php echo base_url();?>assets/scripts/siminta.js"></script>

</body>

</html>
