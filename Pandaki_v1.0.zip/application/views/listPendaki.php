<!DOCTYPE html>
<html>
<head>
	<?php $this->load->view('head'); ?>
</head>

<body>
	<?php
		//echo $this->session->userdata('grupUser');
		if ($this->session->userdata('grupUser')!="admin"){
		redirect('welcome');
	}?>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <?php $this->load->view('header'); ?>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
            <?php $this->load->view('top_list'); ?>
            <!-- end navbar-top-links -->
        </nav>
        <!-- end navbar top -->

        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php $this->load->view('navbar'); ?>
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">List Pendaki</h1>
                </div>
                <!--End Page Header -->
            </div>
			
			<div class="row">
                <div class="col-lg-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List Pendaki
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th>L/P</th>
                                            <th>No. Hp</th>
                                            <th>Alamat</th>
                                            <th>Email</th>
											<th>Umur</th>
											<th>Riwayat Penyakit</th>
											<th>Group</th>
											<th>Long</th>
											<th>Lat</th>
											<th>Keterangan</th>
											<th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php	
											foreach($pendaki as $p){
										?>
											<tr class="odd gradeX">
                                            <td><?php echo $p['nama'];?></td>
											<td><?php echo $p['gender'];?></td>
											<td><?php echo $p['hp'];?></td>
											<td><?php echo $p['alamat'];?></td>
											<td><?php echo $p['email'];?></td>
											<td><?php echo $p['umur'];?></td>
											<td><?php echo $p['penyakit'];?></td>											
											<td><?php if ($p['groupid'] != null){								
											echo $p['groupid'];
											}
											else{			
											echo "belum terdaftar di group";}?></td>
											<td><?php echo $p['long'];?></td>
											<td><?php echo $p['lat'];?></td>
                                            <td><a><button type="button" class="btn btn-danger">Kembali</button></a></td>
											<td><a href ="<?php echo base_url();?>index.php/pendaki/deleteUser/<?php echo $p['username'];?>"><button type="button" class="btn btn-warning">Delete</button></a></td>
											<!--</a>-->
                                        </tr>
										<?php
										}
										?>
                                    </tbody>
                                </table>
                            </div>
							
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
					<div>
								<a href ="<?php echo base_url('index.php/pendaki/addGroup'); ?>"><button type="button" class="btn btn-primary">Grup Baru</button></a></td>			
							</div>

            

        </div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url();?>assets/plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/pace/pace.js"></script>
    <script src="<?php echo base_url();?>assets/scripts/siminta.js"></script>

</body>

</html>
