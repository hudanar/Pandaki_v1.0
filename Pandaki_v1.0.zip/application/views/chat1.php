<!DOCTYPE html>
<html>

<head>
	<?php $this->load->view('head'); ?>
</head>

<body>
	<?php
		//echo $this->session->userdata('grupUser');
		if ($this->session->userdata('grupUser')!="admin"){
		redirect('welcome');
	}?>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <?php $this->load->view('header'); ?>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
            <?php $this->load->view('top_list'); ?>
            <!-- end navbar-top-links -->
        </nav>
        <!-- end navbar top -->

        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php $this->load->view('navbar'); ?>
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">
            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Personal Chat</h1>
                </div>
                <!--End Page Header -->
            </div>
			<div class="row">
			        <div id="echo">
          <div id="echo-config" style="float: left;">
            <strong>Location:</strong><br>
            <input type = "hidden" id="wsUri" size="35" value="ws://singateknologicoid-via.cloud.revoluz.io:49290">
            
			<input type="checkbox" id="secureCb" onclick="toggleTls();" disabled="">
            <span id="secureCbLabel" style="font-size: smaller; color: rgb(153, 153, 153);">Use secure WebSocket (TLS)</span><br>
            <button id="connect" disabled="">Connect</button>
            <button id="disconnect">Disconnect</button>
            <br>
            <br>
			
			<input type = "hidden"class="form-control" id="flag" name="flag" value="pc" readonly>
			<input type = "hidden"class="form-control" id="sender" name="sender" value="<?php echo $this->session->userdata('namaUser');?>" readonly>
			<strong>Send To:</strong><br>
			<input class="form-control" id="usernamex" name="usernamex" value="<?php echo $username;?>" readonly>
			<strong>Message:</strong><br>	
            <input id = "sendMessage" class="form-control" placeholder="Ketik Pesan">
            <br>
            <button id="send" class="wsButton">Send</button>
            <br>
            <div id="displayLog"></div> <br>
          </div>
          <div id="echo-log" style="float: left; margin-left: 20px; padding-left: 20px; width: 350px; border-left: solid 1px #cccccc;"> <strong>Log:</strong>
            <div id="consoleLog"></div>
            <button id="clearLogBut" style="position: relative; top: 3px;">Clear log</button>
          </div>
          <div class="clearfix"></div>
        </div>

		<!--
				<div class="form-group">
					<label></label>
					<textarea id = "consoleLog" class="form-control" rows="3" readonly></textarea>
				</div>
				<div class="form-group">
					<input class="form-control" id="username" name="username" value="<?php echo $username;?>" readonly>
				</div>
				<div class="form-group">
					<input id = "sendMessage" class="form-control" placeholder="Ketik Pesan">
				</div>
				<button id="connect">Connect</button>
				<button id="disconnect">Disconnect</button>
				<button id = "send" type="submit" class="btn btn-primary">Sand</button>
				<button id="clearLogBut" style="position: relative; top: 3px;">Clear log</button>
			-->
			</div>
			</div>
        <!-- end page-wrapper -->
    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url();?>assets/plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/pace/pace.js"></script>
    <script src="<?php echo base_url();?>assets/scripts/siminta.js"></script>
    <script src="<?php echo base_url();?>assets/echo_files/echo.js"></script>
	
</body>

</html>
