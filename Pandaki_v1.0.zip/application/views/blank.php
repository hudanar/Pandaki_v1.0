<!DOCTYPE html>
<html>

<head>
	<?php $this->load->view('head'); ?>
</head>

<body>
	<?php
		//echo $this->session->userdata('grupUser');
		if ($this->session->userdata('grupUser')!="admin"){
		redirect('welcome');
	}?>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <?php $this->load->view('header'); ?>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
            <?php $this->load->view('top_list'); ?>
            <!-- end navbar-top-links -->
        </nav>
        <!-- end navbar top -->

        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php $this->load->view('navbar'); ?>
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">
            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Dashboard</h1>
                </div>
                <!--End Page Header -->
            </div>
			
			<div class="row">
                <!-- Welcome -->
                <div class="col-lg-12">
                    <div class="alert alert-info">
                        <i class="fa fa-folder-open"></i><b>&nbsp;Hai ! </b>Selamat Datang <b> Admin <?php echo $this->session->userdata('namaUser');?> </b>
                    </div>
                </div>
                <!--end  Welcome -->
            </div>
			
			<div class="row">
                <!--quick info section -->
                <div class="col-lg-3">
                    <div class="alert alert-success text-center">
                        <i>icon</i>&nbsp;<b>jml Kunjungan </b>Total pengunjung dalam 1 bulan  
                    </div>
                </div>
				<div class="col-lg-3">
                    <div class="alert alert-danger text-center">
                        <i>icon</i>&nbsp;<b>jml pendaki</b>n perempuan m laki-laki
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="alert alert-info text-center">
                        <i>icon</i>&nbsp;<b>yg masih di atas</b>jumlah yang masih belum turun

                    </div>
                </div>
				<div class="col-lg-3">
                    <div class="alert alert-info text-center">
                        <i>icon</i>&nbsp;<b>laporan kasus</b>laporan kasus

                    </div>
                </div>
                <!--end quick info section -->
            </div>
			
			<div class="row">
			<!-- monintoring-->
                <div class="col-lg-12">
					<div class="panel panel-primary">
						<div class="panel-heading">
							Monitoring Lokasi
						</div>
						<div class="panel-body">
                            <div>
							Nanti di isi sama peta
							</div>
                        </div>
					</div>					
				</div>
			</div>
        </div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url();?>assets/plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/pace/pace.js"></script>
    <script src="<?php echo base_url();?>assets/scripts/siminta.js"></script>

</body>

</html>
