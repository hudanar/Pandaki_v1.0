<!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                    <li>
                        <!-- user image section-->
                        <div class="user-section">
                            <div class="user-section-inner">
                                <img src="<?php echo base_url();?>assets/img/user.jpg" alt="">
                            </div>
                            <div class="user-info">
                                <div><?php echo $this->session->userdata('namaUser');?><strong>Admin</strong></div>
                                <div class="user-text-online">
                                    <span class="user-circle-online btn btn-success btn-circle "></span>&nbsp;Online
                                </div>
                            </div>
                        </div>
                        <!--end user image section-->
                    </li>
                    <li class="sidebar-search">
                        <!-- search section-->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <!--end search section-->
                    </li>
                    <li class="">
                        <a href = "<?php echo base_url('index.php/welcome/masuk'); ?>"><i class="fa fa-dashboard fa-fw"></i>Dashboard</a>
                    </li>
					<li>
                        <a href="#"><i class="fa fa-edit fa-fw"></i>Pendaki<span class="fa arrow"></span></a>
						<ul class="nav nav-second-level">
                            <li>
								<a href="<?php echo base_url('index.php/pendaki/verifikasi'); ?>"><i class="fa fa-flask fa-fw"></i>Verifikasi</a>
							</li>
							<li>
								<a href="<?php echo base_url('index.php/pendaki/listPendaki'); ?>"><i class="fa fa-edit fa-fw"></i>List Pendaki</a>
							</li>
							<li>
								<a href="<?php echo base_url('index.php/pendaki/listGroup'); ?>"><i class="fa fa-edit fa-fw"></i>List Group</a>
							</li>
                        </ul>
                    </li>
                    
                    <li>
                        <a href="#"><i class="fa fa-edit fa-fw"></i>Chat <span class="fa arrow"></span></a>
						<ul class="nav nav-second-level">
                            <li>
                                <a href="<?php echo base_url('index.php/chat/personalChat'); ?>">Personal</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('index.php/chat/broadcashChat'); ?>">Broadcast</a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="<?php echo base_url('index.php/infoTips'); ?>"><i class="fa fa-edit fa-fw"></i>Info dan Tips</a>
                    </li>
                   
                </ul>
                <!-- end side-menu -->
            </div>
            <!-- end sidebar-collapse -->