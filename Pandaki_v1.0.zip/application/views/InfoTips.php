<!DOCTYPE html>
<html>

<head>
	<?php $this->load->view('head'); ?>
</head>

<body>
	<?php
		//echo $this->session->userdata('grupUser');
		if ($this->session->userdata('grupUser')!="admin"){
		redirect('welcome');
	}?>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <?php $this->load->view('header'); ?>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
            <?php $this->load->view('top_list'); ?>
            <!-- end navbar-top-links -->
        </nav>
        <!-- end navbar top -->

        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php $this->load->view('navbar'); ?>
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Info dan Tips</h1>
                </div>
                <!--End Page Header -->
            </div>
			<div>
			<!--  Bordered Table  -->
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
						<a href="<?php echo base_url();?>index.php/infoTips/addNew"><button type="submit" class="btn btn-primary">Tambah Baru</button></a>
                        <div class="panel-heading">
                            Info
                        </div>
							<div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Judul</th>
                                            <th>Tipe</th>
											<th>Gambar</th>
                                            <th>Konten</th>
											<th>Edit</th>
                                        </tr>
                                    </thead>
									
                                    <tbody>
                                        <?php	
											foreach($info as $p){
										?>
											<tr class="odd gradeX">
                                            <td><?php echo $p['id'];?></td>
											<td><?php echo $p['judul'];?></td>
											<td><?php echo $p['tipe'];?></td>
											<td><?php echo $p['foto'];?></td>
											<td><?php echo $p['konten'];?></td>
											<td><a href ="<?php echo base_url();?>index.php/infoTips/deleteInfo/<?php echo $p['id'];?>"><button type="button" class="btn btn-warning">Delete</button></a></td>
											<!--</a>-->
                                        </tr>
										<?php
										}
										?>
                                    </tbody>
                                </table>
                            </div>
							    <div class="panel-heading">
                            Tips
                        </div>
							<div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Judul</th>
                                            <th>Tipe</th>
											<th>Gambar</th>
                                            <th>Konten</th>
											<th>Edit</th>
                                        </tr>
                                    </thead>
									
                                    <tbody>
                                        <?php	
											foreach($in as $t){
										?>
											<tr class="odd gradeX">
                                            <td><?php echo $t['id'];?></td>
											<td><?php echo $t['judul'];?></td>
											<td><?php echo $t['tipe'];?></td>
											<td><?php echo $t['foto'];?></td>
											<td><?php echo $t['konten'];?></td>
											<td><a href ="<?php echo base_url();?>index.php/infoTips/deleteInfo/<?php echo $t['id'];?>"><button type="button" class="btn btn-warning">Delete</button></a></td>
											<!--</a>-->
                                        </tr>
										<?php
										}
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!--  End  Bordered Table  -->
			</div> 	 	
        </div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url();?>assets/plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/pace/pace.js"></script>
    <script src="<?php echo base_url();?>assets/scripts/siminta.js"></script>

</body>

</html>
