<!DOCTYPE html>
<html>
<head>
	<?php $this->load->view('head'); ?>
</head>

<body>
	<?php
		echo $this->session->userdata('grupUser');
		if ($this->session->userdata('grupUser')!="admin"){
		redirect('welcome');
	}?>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <?php $this->load->view('header'); ?>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
            <?php $this->load->view('top_list'); ?>
            <!-- end navbar-top-links -->
        </nav>
        <!-- end navbar top -->

        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php $this->load->view('navbar'); ?>
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Detail Data Pendaki</h1>
                </div>
                <!--End Page Header -->
            </div>
			<div class="row">
			<div class="col-lg-6">
			<div class="panel-body">
				<div class="table-responsive">
				<table class="table">
                    <tbody>
                        <tr>
                            <td>Nama</td>
                            <td>Mark</td>
                        </tr>
                        <tr>
							<td>Alamat</td>
							<td>Jln. xxxx xxxx xxxx</td>
						</tr>
						<tr>
							<td>Usia</td>
							<td>20</td>
						</tr>
						<tr>
							<td>Data 1</td>
							<td>lalala</td>
						</tr>
						<tr>
							<td>Data 2</td>
							<td>Yeyeye</td>
						</tr>
					</tbody>
				</table>
				</div>
				</div>
				</div>
			</div>
			<div class="row">
			<div class="col-lg-6">
				<button type="button" class="btn btn-danger">Verifikasi</button>
				</div>
			</div>
        </div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url();?>assets/plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/pace/pace.js"></script>
    <script src="<?php echo base_url();?>assets/scripts/siminta.js"></script>

</body>

</html>
