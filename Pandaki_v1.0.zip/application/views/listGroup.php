<!DOCTYPE html>
<html>
<head>
	<?php $this->load->view('head'); ?>
</head>

<body>
	<?php
		//echo $this->session->userdata('grupUser');
		if ($this->session->userdata('grupUser')!="admin"){
		redirect('welcome');
	}?>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <?php $this->load->view('header'); ?>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
            <?php $this->load->view('top_list'); ?>
            <!-- end navbar-top-links -->
        </nav>
        <!-- end navbar top -->

        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php $this->load->view('navbar'); ?>
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">List Pendaki</h1>
                </div>
                <!--End Page Header -->
            </div>
			
			<div class="row">
                <div class="col-lg-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List Pendaki
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>ID Group</th>
                                            <th>Anggota</th>
											<th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php	
											for($i=0; $i < count($pendaki) ; $i++){?>
											
											<tr class="odd gradeX">
                                            <td><?php echo $pendaki[$i][0];?></td>
											<td>
											<?php
											for($j = 0; $j < count($pendaki[$i][1]) ; $j++){
											
										?>
											<?php echo $pendaki[$i][1][$j];?></br>
                                            
										<?php
										}
										?>
										</td>
										<td><a href ="<?php echo base_url();?>index.php/pendaki/deleteGroup/<?php echo $pendaki[$i][0];?>"><button type="button" class="btn btn-warning">Delete</button></a></td>
											<!--</a>-->
                                        </tr>
										<?php
										}
										?>
                                    </tbody>
                                </table>
                            </div>
							
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
					<div>
								<a href ="<?php echo base_url('index.php/pendaki/addGroup'); ?>"><button type="button" class="btn btn-primary">Grup Baru</button></a></td>			
							</div>

            

        </div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url();?>assets/plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/pace/pace.js"></script>
    <script src="<?php echo base_url();?>assets/scripts/siminta.js"></script>

</body>

</html>
