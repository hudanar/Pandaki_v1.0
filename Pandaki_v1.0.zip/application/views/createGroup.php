<!DOCTYPE html>
<html>

<head>
    <?php $this->load->view('head'); ?>
</head>

<body>
	<?php
		echo $this->session->userdata('grupUser');
		if ($this->session->userdata('grupUser')!="admin"){
		redirect('welcome');
	}?>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <?php $this->load->view('header'); ?>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
            <?php $this->load->view('top_list'); ?>
            <!-- end navbar-top-links -->
        </nav>
        <!-- end navbar top -->

        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php $this->load->view('navbar'); ?>
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">
            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Buat Group Baru</h1>
                </div>
                <!--End Page Header -->
            </div>
			<div class = "row">
			<!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List Pendaki
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
											<th>UserName</th>
                                            <th>Nama</th>
                                            <th>L/P</th>
                                            <th>No. Hp</th>
                                            <th>Alamat</th>
                                            <th>Email</th>
											<th>Umur</th>
											<th>Riwayat Penyakit</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php
											foreach($pendaki as $p){
											if ($p['groupid'] == null){
										?>
											<tr class="odd gradeX">
                                            <td><?php echo $p['username'];?></td>
                                            <td><?php echo $p['nama'];?></td>
											<td><?php echo $p['gender'];?></td>
											<td><?php echo $p['hp'];?></td>
											<td><?php echo $p['alamat'];?></td>
											<td><?php echo $p['email'];?></td>
											<td><?php echo $p['umur'];?></td>
											<td><?php echo $p['penyakit'];?></td>
                                        </tr>
										<?php
										}
										}
										?>
                                    </tbody>
                                </table>
                            </div>
							
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
			</div>
			<div class="row">
				<form role="form" method="post" action="<?php echo base_url();?>index.php/pendaki/simpanAnggotaGroup">
					<div class="form-group">
						<label>Anggota Baru</label>		
						<!--
						<input class="form-control" placeholder="Jumlah Anggota" name="jmlAnggota">
						-->
						<input class="form-control" placeholder="tulis username anggota" name="anggota">
						<!--
						<?php
						$i=0;
						foreach($pendaki as $p){
						?>
						<input type="checkbox" name="nilai_<?php echo $i;?>" value="<?php echo $p['username']?>"> <?php echo $p['nama']?><br>
						<?php $i ++;}?>
						-->
					</div>
					<input type="submit" value="SUBMIT" name="submit" class="btn btn-primary"></input>
				</form>
				
			</div>
        </div>
        <!-- end page-wrapper -->
    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/plugins/pace/pace.js"></script>
    <script src="assets/scripts/siminta.js"></script>

</body>

</html>
