<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

public $host = "http://singateknologicoid-via.cloud.revoluz.io:49180";

		public function in()
		{
			$url = $this->host."/api/serv1/v1.0/pandaki/login";
			//echo "host= ".$url;
			$msg = '';
			$name = $this->input->post('username');
			$pass = $this->input->post('password');
			
			$data = array (
			'username'=> $name,
			'password'=> $pass);
			
			$data = http_build_query($data);
			
			$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
            'header'=> "Content-type: application/x-www-form-urlencoded\r\n"
                . "Content-Length: " . strlen($data) . "\r\n",
            'content' => $data
			)
			));	
			// Send the request
			$response = file_get_contents($url,FALSE, $context);
			// Check for errors
			if($response === FALSE){
				die('Error');
			}
			// Print the date from the response
			//echo $response;
			if ($response == "admin")
				{
					$userdata = array('namaUser'=> $name, 'grupUser'=> 'admin',
					'logged_in' => TRUE
					);
					$this->session->set_userdata
					($userdata); 
					$cek = $this->session->userdata('grupUser');
					redirect('welcome/masuk');
				} 
				else 
				{
					$msg = $response;
					$this->load->view('login',$msg);
							
				}
		}
		
		public function out()
		{
			$this->session->sess_destroy();
			redirect ('welcome');
		}

}
