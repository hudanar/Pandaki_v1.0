<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chat extends CI_Controller {

public $url = "http://singateknologicoid-via.cloud.revoluz.io:49180";

	public function personalChat()
	{
		$dataCoba = file_get_contents($this->url.'/api/serv1/v1.0/pandaki/pendaki');
		$dataCoba=(json_decode($dataCoba, true));
		//echo $dataCoba;
		$this->load->view('listPendakiChat',array ('pendaki'=>$dataCoba));
	}
	public function pc($username){
		$data['username']=$username;
		$this->load->view('chat1', $data);
	}
	public function doPC($username){
		$data['username']=$username;
		$this->load->view('chat1', $data);
	}
	
	public function broadcashChat()
	{
		$this->load->view('chat2');
	}
	
}
