<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class InfoTips extends CI_Controller {
    
public $url = "http://singateknologicoid-via.cloud.revoluz.io:49180";
	public function index()
	{
		$dataInfo = file_get_contents($this->url.'/api/serv1/v1.0/pandaki/infotips/info');
		//echo "Info".$dataInfo."</br>";
		$dataInfo=(json_decode($dataInfo, true));
		$dataTips = file_get_contents($this->url.'/api/serv1/v1.0/pandaki/infotips/tips');
		//echo "Tips".$dataTips;
		$dataTips=(json_decode($dataTips, true));
		$this->load->view('InfoTips',array ('info'=>$dataInfo,'in'=>$dataTips));
	}
	public function addNew(){
		$this->load->view('datailInfo');
	}
	public function add(){
		/*MASIH BELUM HAHAHAHA*/
		$url = $this->url."/api/serv1/v1.0/pandaki/infotips";
		$msg = '';
			$judul = $this->input->post('judul');
			$tipe = $this->input->post('tipe');
			$foto = $this->input->post('foto');
			$konten = $this->input->post('konten');
			
			$data = array (
			//'id'=>1,
			'judul'=> $judul,
			'tipe'=> $tipe,
			'konten'=>$konten,
			'foto'=>$foto
			);		
			
			//$data = http_build_query($data);

			$options = array(
				'http' => array(
				'method'  => 'POST',
				'content' => json_encode( $data ),
				'header'=>  "Content-Type: application/json\r\n" .
						"Accept: application/json\r\n"
				)
			);

			$context  = stream_context_create( $options );
			$response = file_get_contents( $url, false, $context );
			//$response = json_decode( $result );
			// Check for errors
			if($response === FALSE){
				die('Error');
			}
			// Print the date from the response
			//echo $response;
			$this->index();
	
	}
	public function deleteInfo($id){
		$context = stream_context_create(array(
			'http' => array(
			'method' => 'DELETE')
			));	
			$url = $this->url."/api/serv1/v1.0/pandaki/infotips/info".$id;
			$response = file_get_contents($url,FALSE, $context);
			// Check for errors
			if($response === FALSE){
				die('Error');
			}
			
			$this->index();
	
	}
	public function deleteTips($id){
		$context = stream_context_create(array(
			'http' => array(
			'method' => 'DELETE')
			));	
			$url = $url."/api/serv1/v1.0/pandaki/infotips/tips".$id;
			$response = file_get_contents($this->url,FALSE, $context);
			// Check for errors
			if($response === FALSE){
				die('Error');
			}			
			$this->index();
	
	
}
}
?>