<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pendaki extends CI_Controller {
//http://192.168.43.73:5001
public $url = "http://singateknologicoid-via.cloud.revoluz.io:49180";

	public function verifikasi()
	{
		$dataCoba = file_get_contents($this->url.'/api/serv1/v1.0/pandaki/calonPendaki');
		
		$dataCoba=(json_decode($dataCoba, true));
		$this->load->view('verifikasi',array ('pendaki'=>$dataCoba));
	}
	public function detailPendaki()
	{
		$this->load->view('detailPendaki');
	}
	public function listPendaki()
	{
		$dataCoba = file_get_contents($this->url.'/api/serv1/v1.0/pandaki/pendaki');
		$dataCoba=(json_decode($dataCoba, true));
		//echo $dataCoba;
		$this->load->view('listPendaki',array ('pendaki'=>$dataCoba));
	}
	public function listGroup()
	{
		$dataCoba = file_get_contents($this->url.'/api/serv1/v1.0/pandaki/group');
		$dataCoba=(json_decode($dataCoba, true));
		//echo $dataCoba[0][1][0];	
		$this->load->view('listGroup',array ('pendaki'=>$dataCoba));
	}
	public function addGroup()
	{	
		$dataCoba = file_get_contents($this->url.'/api/serv1/v1.0/pandaki/pendaki');
		$dataCoba=(json_decode($dataCoba, true));
		$this->load->view('createGroup',array ('pendaki'=>$dataCoba));
	}
	public function simpanAnggotaGroup(){
	echo "masuk";
			$msg = '';
			$anggota = $this->input->post('anggota');
			
			$data = array (
			'anggota'=> $anggota
			//ini nanti yg dibutuhkan apa aja disimpan
			);
			
			$data = http_build_query($data);
			
			$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
            'header'=> "Content-type: application/x-www-form-urlencoded\r\n"
                . "Content-Length: " . strlen($data) . "\r\n",
            'content' => $data
			)
			));	
			// Send the request
			$response = file_get_contents($this->url.'/api/serv1/v1.0/pandaki/group',FALSE, $context);
			// Check for errors
			if($response === FALSE){
				die('Error');
			}
			// Print the date from the response
			//echo $response;
			$this->addGroup();
	
	}
	
	public function deleteUser($id){
		$id = trim(str_replace("%20%20", '', $id));
		$context = stream_context_create(array(
			'http' => array(
			'method' => 'DELETE')
			));	
			$url = $url."/api/serv1/v1.0/pandaki/".$id;

			$response = file_get_contents($this->url,FALSE, $context);
			// Check for errors
			if($response === FALSE){
				die('Error');
			}
			// Print the date from the response
			//echo $response;
			
			$this->listPendaki();
	
	}
		public function deleteGroup($id){
		$id = trim(str_replace("%20%20", '', $id));
		$context = stream_context_create(array(
			'http' => array(
			'method' => 'DELETE')
			));	
			$url = $url."/api/serv1/v1.0/pandaki/group/".$id;

			$response = file_get_contents($this->url,FALSE, $context);
			// Check for errors
			if($response === FALSE){
				die('Error');
			}
			
			$this->listGroup();
	
	}
	public function verPendaki(){
		//echo $id;
			$msg = '';
			$anggota = $this->input->post('username');
			echo $anggota;
			
			$data = array (
			'username'=> $anggota
			);
			
			$data = http_build_query($data);
			echo $data;
			
			$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
            'header'=> "Content-type: application/x-www-form-urlencoded\r\n"
                . "Content-Length: " . strlen($data) . "\r\n",
            'content' => $data
			)
			));	
			// Send the request
			$response = file_get_contents($this->url.'/api/serv1/v1.0/pandaki/validasi',FALSE, $context);
			//$response = file_get_contents('http://singateknologicoid-via.cloud.revoluz.io:49810/api/serv1/v1.0/pandaki/validasi',FALSE, $context);
			// Check for errors
			if($response === FALSE){
				die('Error');
			}else{
			echo $response;
			}
			$this->verifikasi();
			
			
	
	}
	}
